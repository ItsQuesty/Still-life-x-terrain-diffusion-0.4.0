# Compatibility

## Supported baseline

- Minecraft 1.21.1
- Fabric Loader 0.18.1 or newer
- Fabric API
- Terrain Diffusion 2.x for 1.21.1
- Still Life 0.1.1
- Lithosphere 1.7 data pack/mod

## Generic biome compatibility layer

Version 0.4.0 maps all 108 custom Still Life biome registry entries into Fabric's official common
`c:` biome tags. These tags are the loader-level compatibility contract intended for vegetation,
structure, mob, season, and ambience mods.

The mapping covers:

- cold, temperate, and hot climates;
- dry and wet climates;
- dense and sparse vegetation;
- caves, deserts, plains, swamps, beaches, rivers, oceans, mountains, peaks, slopes, and plateaus;
- snowy, icy, sandy, lush, old-growth, spooky, and wasteland environments;
- coniferous, deciduous, jungle, and savanna tree environments.

Still Life's own existing vanilla biome and structure tags remain authoritative and are not replaced.
SLTD only supplies missing common semantics with `replace: false`, allowing other datapacks to extend
the same tags.

This makes standards-compliant mods plug-and-play. A mod that hardcodes exact vanilla biome IDs,
ships `replace: true` tags, or replaces the overworld biome source cannot be repaired generically
without risking incorrect generation. Such a mod needs a small dedicated adapter.

## Distant Horizons

Supported. SLTD configures Distant Horizons to generate distant terrain through the internal server,
which uses the same TD terrain, Still Life biome bridge, surfaces, hydrology, and features as nearby
chunks.

SLTD changes only these Distant Horizons settings:

- `worldCompression = "MERGE_SAME_BLOCKS"`
- `disableUnchangedChunkCheck = true`
- `distantGeneratorMode = "INTERNAL_SERVER"`
- `overrideVanillaGraphicsSettings = false`
- `overdrawPrevention = "-1.0"`
- `reduceOverdrawWithFastMovement = false`
- `grassSideRendering = "AS_GRASS"`

This mode is slower than DH's feature-only generator because it creates real server chunks, but it is
the reliable path for matching complex modded world generation.

## Farmer's Delight Refabricated

Compatible. It adds food, crops, blocks, recipes, and structures without replacing Terrain
Diffusion's density generation or SLTD's biome source. No SLTD-specific configuration is required.

## Serene Seasons

Compatible in principle with the Fabric 1.21.1 build. Serene Seasons requires GlitchCore.

SLTD exposes real Still Life biome registry entries, temperatures, precipitation, tags, surfaces, and
features rather than disguising them as vanilla biomes. That gives season integrations the correct
biome data to inspect. Serene Seasons may still require its own biome/crop configuration for exact
snow behavior or custom seasonal crop rules across all 109 Still Life biomes.

## Project Atmosphere

Not load-compatible with this release. Project Atmosphere's Minecraft 1.21.1 release is for NeoForge,
while SLTD and Terrain Diffusion are running on Fabric. Its advertised Still Life climate conversion
does not change the loader incompatibility.

A future Fabric build of Project Atmosphere should be evaluated against TD's climate output before it
is declared supported.

## Performance mods

The tested baseline includes Sodium, Lithium, FerriteCore, ImmediatelyFast, BadOptimizations, Iris,
and Distant Horizons. These are optional and are not bundled.
