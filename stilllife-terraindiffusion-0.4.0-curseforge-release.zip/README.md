# Still Life × Terrain Diffusion

A Fabric 1.21.1 compatibility mod that makes the **Still Life** biome set generate on
**Terrain Diffusion**'s AI terrain — at any world scale — the way it would on a normal
Lithosphere world.

## What it does

Terrain Diffusion replaces world generation with an ONNX diffusion model and assigns biomes from a
hardcoded ~23-biome vanilla palette (`BiomeClassifier` → `TerrainDiffusionBiomeSource`). Still Life,
normally, places its **109-biome set** with a `multi_noise` biome source containing 3988
climate-parameter boxes, on top of Lithosphere's terrain.

This mod bridges the two. It registers a biome source `sltd:climate_bridge` and a datapack override
of TD's world preset so the Terrain Diffusion overworld uses it. For every column the bridge:

1. samples Terrain Diffusion's model output (elevation, slope, temperature, precipitation) using TD's
   public API and caches — no second model run;
2. converts those physical quantities into Minecraft's six climate parameters
   (continentalness←elevation, erosion←slope, temperature, humidity, depth←`surfaceY−y`, weirdness);
3. runs **Still Life's own** multi-noise box search to pick the biome.
4. applies Still Life's installed overworld surface rule to TD and rescales high snow/alpine Y
   anchors for the selected TD world scale.

Because `depth` is computed relative to the surface and the other parameters are physical, biome
placement is scale-independent and also yields Still Life's depth-based cave biomes.

## Upland freshwater

TD's density function is one terrain height per column, its aquifers are disabled, and its fluid
picker fills only below sea level. Merely assigning a Still Life river or wetland biome cannot create
water above Y=63; those biomes decorate water that already exists.

Version 0.2.0 adds a real noise-stage freshwater pass inside this mod:

- terrain and precipitation are analyzed on TD's native 30-metre grid, keeping the same watershed
  geometry at world scales 1–6;
- wet valley centerlines become shallow source-water streams;
- sufficiently wet closed depressions are flood-filled to a single basin water level;
- the same deterministic field selects the climate-appropriate Still Life river biome, so water
  colour, banks, mud, seagrass, fish, vegetation, and mob rules agree with the generated water;
- water is added after TD finishes density generation but before Still Life surfaces, carvers, and
  features. Distant Horizons therefore uses the same result as normal chunk generation.

Hydrology affects **newly generated chunks only**. Existing chunks are never rewritten.

Still Life's parameter table is read at runtime from the installed datapack — **nothing from Still
Life is bundled** (it is All-Rights-Reserved). Terrain Diffusion is MIT and is a normal mod
dependency (not bundled either).

## Requirements (load order handled by dependencies)

- Minecraft 1.21.1, Fabric Loader ≥ 0.18.1, Fabric API
- Terrain Diffusion (`terrain-diffusion-mc`) 2.x for 1.21.1
- Still Life (`mr_still_life`)
- Lithosphere (`mr_lithosphere`) — kept installed so Still Life's data references resolve; its terrain
  is unused under Terrain Diffusion.

Create a world with the **Terrain Diffusion** world type as usual. Pick the world scale you want; the
bridge adapts to it.

## Distant Horizons

When Distant Horizons is installed, version 0.3.1 automatically applies the settings required to
make unvisited LOD terrain use normal server chunk generation instead of DH's incompatible
feature-only generator. This removes the coloured chunk-boundary lines and missing/incorrect distant
terrain seen with Still Life features while preserving vanilla rendering in the foreground.

The original `config/DistantHorizons.toml` is backed up once as
`config/DistantHorizons.toml.sltd-backup`. Automatic configuration can be disabled by setting
`configureDistantHorizons=false` in `config/sltd.properties`.

If Distant Horizons has never launched before, it creates its config on the first launch and SLTD
patches it on the next launch.

## Other mod compatibility

See `COMPATIBILITY.md`. In short:

- Version 0.4.0 projects every Still Life biome into Fabric's official `c:` climate, moisture,
  vegetation, terrain, and tree-type biome tags. Tag-aware vegetation, structure, and mob mods can
  therefore recognize Still Life biomes without dedicated SLTD code.
- Farmer's Delight Refabricated is compatible.
- Serene Seasons is compatible in principle on Fabric 1.21.1 and requires GlitchCore. Still Life
  biome-specific seasonal tuning remains the responsibility of the season mod/configuration.
- Project Atmosphere's Minecraft 1.21.1 release is NeoForge-only, so it cannot load in this Fabric
  build.

No generic bridge can safely repair a mod that explicitly hardcodes vanilla biome IDs or replaces the
overworld biome source. Those mods need a small named adapter; SLTD's common tags provide the stable
API for doing that without editing Still Life.

## CurseForge distribution

The built jar is ready for a CurseForge mod project, but a jar cannot directly download other mods.
CurseForge installs dependencies through project Relations, and Terrain Diffusion plus the required
Still Life/Lithosphere 1.21.1 files are not all available as CurseForge projects. See
`CURSEFORGE_RELEASE.md` for the exact upload and pack-distribution workflow.

## Building

```
./gradlew build                 # jar in build/libs/
./gradlew curseForgeRelease     # uploader bundle in build/distributions/
```

JDK 21 required. `libs/terrain-diffusion-mc-*.jar` is a compile-only dependency (Loom remaps it); it
is provided at runtime by the user's install and is not shipped inside this jar.

## Automated tests

`./gradlew test` runs a game-free validation of the climate→biome mapping (no GPU, no Minecraft
launch). It loads Still Life's installed parameter table, sweeps the whole climate input space through
`ClimateMapper`, runs the same nearest-box search vanilla uses, and checks:

- **`paramSanity`** — the physical→Minecraft-climate mapping is well-formed: monotonic temperature /
  humidity / continentalness, non-increasing erosion, submerged columns land in the ocean
  continentalness range, depth grows downward and clamps.
- **`coverageAndInvariants`** — every Still Life biome is reachable (currently **109/109**),
  no beach biome on submerged columns, deep columns resolve to ocean. Writes a coverage histogram to
  `build/sltd-climate-report.txt`.
- **`HydrologyMathTest`** — valleys produce streams, ridges and arid valleys do not, and lake levels
  stay above basin floors and below spill rims.

Biome *identity* on land is intentionally not asserted — we run Still Life's own box search, so whatever
it returns for a climate is, by construction, what Still Life would place. Tuning `ClimateMapper` until
this suite is green is the calibration loop.

## Status / roadmap

- **Working:** all 109 Still Life biomes, Still Life surfaces, scale-adjusted alpine/snow anchors,
  features, vegetation, mob spawning, colours, and terrain-derived upland freshwater on TD terrain.
- **v1 calibration:** the physical→Minecraft climate mapping in `ClimateMapper` uses first-pass
  piecewise anchors. Tune them against a side-by-side biome histogram vs a normal Lithosphere+Still
  Life world for an exact distribution match.
- **Still intentional:** Lithosphere remains installed for Still Life's registry/data dependencies,
  but TD supplies all terrain density. No Lithosphere density or river terrain is mixed into the world.
