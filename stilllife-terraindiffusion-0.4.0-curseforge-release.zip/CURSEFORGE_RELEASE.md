# CurseForge release instructions

## Upload artifact

Upload the remapped jar from:

`build/libs/stilllife-terraindiffusion-0.4.0.jar`

Do not upload the sources jar. The zip in `build/distributions` is an uploader/reference bundle, not a
Minecraft modpack import.

Use these project settings:

- Game version: Minecraft 1.21.1
- Mod loader: Fabric
- Java: 21
- Release type: Beta until wider world-scale and modpack testing is complete
- License: MIT

## Required Relations

Add CurseForge Required Dependency relations for every dependency that has a CurseForge project:

- Fabric API
- Terrain Diffusion, only if its exact 1.21.1 distribution has a CurseForge project
- Still Life, only if its exact 1.21.1 distribution has a CurseForge project
- Lithosphere, only if its exact 1.21.1 distribution has a CurseForge project

Do not substitute similarly named or older files. SLTD's `fabric.mod.json` also blocks launch when a
required mod ID is missing, preventing silent broken worlds.

## Optional Relations

- Distant Horizons
- Sodium
- Lithium
- FerriteCore
- ImmediatelyFast
- Iris
- BadOptimizations
- Farmer's Delight Refabricated
- Serene Seasons
- GlitchCore

Project Atmosphere must not be listed for this Fabric 1.21.1 release because its 1.21.1 build is
NeoForge-only.

## Important dependency limitation

A Fabric mod jar cannot install other jars. CurseForge auto-downloads dependencies only through
CurseForge project Relations. At the time of this release, the exact Terrain Diffusion, Still Life,
and Lithosphere files used by the tested instance are not all represented as compatible CurseForge
projects.

Therefore:

1. The SLTD jar is ready to add to any correctly prepared Fabric 1.21.1 pack.
2. Distant Horizons configuration is automatic after installation.
3. A genuinely automatic CurseForge pack install is possible only after every required dependency is
   hosted on CurseForge and linked through Relations.
4. Do not bundle or redistribute Still Life or Lithosphere files without their authors' explicit
   permission; their installed releases are All Rights Reserved.

For a private pack, install the required files from their official sources, then export the CurseForge
profile. CurseForge may omit non-CurseForge files from the export, so verify the exported manifest and
test it in a clean instance before publishing.
